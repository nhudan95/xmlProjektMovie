Name, Vorname, Matrikelnummer, E-Mail-Adresse, Studiengang, Semester

Manfo, Christiane, 406244, cmanfo@stud.hs-bremen.de, Ifi, 7
Muravytska, Mariia, 414730, mmuravytska@stud.hs-bremen.de, Ifi, 7 
Nguyen, Nhu Dan, 405420, nhnguyen@stud.hs-bremen.de, Ifi, 7